<?php
include("config/dbcon.php");
session_start();
if (isset($_POST['addnews'])) {
    $title = $_POST['title'];
    $body = $_POST['body'];
    $news_by = $_SESSION['user'];

    $news_query = "INSERT INTO news(n_title,n_body,n_by) VALUES ('$title','$body','$news_by')";
    $news_query_run = mysqli_query($con, $news_query);
    if ($news_query_run) {
        $_SESSION["query_success"] = true;
        $_SESSION['status'] = "<b>NEWS</b>   Aded Successfuly";
        header("LOCATION: add_news.php");
        die();
    } else {
        $_SESSION["query_success"] = false;
        $_SESSION['status'] = "Sorry !!! <b> News Not Added</b>";
        header("LOCATION: add_news.php");
        die();
    }
}
