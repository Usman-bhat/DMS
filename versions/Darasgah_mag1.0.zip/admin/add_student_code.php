
<?php
session_start();
include("config/dbcon.php");

if (isset($_POST["addstudent"])) {

    $addno = $_POST['addno'];
    $formno = $_POST['formno'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $aadharno = $_POST['aadharno'];
    $dob = $_POST['dob'];
    $doa = $_POST['doa'];
    $phno = $_POST['phno'];
    $parantage = $_POST['parantage'];
    $class = $_POST['class'];
    $status = $_POST['status'];
    $image = $_FILES['image']['name'];

    $allowed_extension = array('png', 'jpg', 'jpeg');
    $file_extension = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time() . '.' . $file_extension;

    if (!in_array($file_extension, $allowed_extension)) {
        $_SESSION['status'] = "extenson not allowed";
        header("header: add_stuent.php");
        exit(0);
    } else {


        $student_query = "INSERT INTO students(t_admission_no,t_form_no,t_name,t_parentage,t_address,t_aadhar,t_admission_date,t_dob,t_phone_number,t_class,t_status,t_photo) 
                        VALUES ('$addno','$formno','$name','$parantage','$address','$aadharno','$doa','$dob','$phno','$class','$status','$filename')";

        $stuent_query_run = mysqli_query($con, $student_query);
        if ($stuent_query_run) {
            move_uploaded_file($_FILES['image']['tmp_name'], 'images/student_images/' . $filename);
            $_SESSION["query_success"] = true;
            $_SESSION['status'] = "Student Added Successfull";
            header("LOCATION: add_student.php");
        } else {
            $_SESSION["query_success"] = false;
            $_SESSION['status'] = "Student regestration Faled";
            header("LOCATION: add_student.php");
        }
    }
}
